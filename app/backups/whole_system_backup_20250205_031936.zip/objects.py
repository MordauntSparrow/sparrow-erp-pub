import os
import json
import importlib
import requests
import shutil
import zipfile
import subprocess
import sys
from datetime import datetime, timedelta
from packaging.version import parse
from urllib.parse import urlparse, quote
from apscheduler.schedulers.background import BackgroundScheduler


class UpdateManager:
    CORE_MANIFEST_REMOTE_URL = "https://gitlab.com/api/v4/projects/sparrow-erp%2FCore/repository/files/manifest.json/raw?ref=main"
    PLUGIN_MANIFEST_REMOTE_URL_TEMPLATE = "https://gitlab.com/api/v4/projects/sparrow-erp%2FCore/repository/files/plugins/%s/manifest.json/raw?ref=main"
    GITLAB_TOKEN = "glpat-g9cg9RxhwcVLio1wuDb1"  # Replace with your token here
    UPDATE_DIR = "app/updates"
    BACKUP_DIR = "app/backups"
    PLUGIN_PATH = "app/plugins"
    LOG_PATH = "app/logs/update_history.json"
    CORE_PATH = "app/core"  # Not used for core updates anymore since whole system is backed up

    def __init__(self, plugins_dir='plugins'):
        # Assume PluginManager is defined elsewhere in your project.
        self.plugin_manager = PluginManager(plugins_dir)
        self.scheduler = BackgroundScheduler()
        self.scheduler.start()  # Start the scheduler
        self.ensure_directories()
        # Schedule regular plugin checks.
        self.scheduler.add_job(self.check_and_download_new_plugins, 'interval', hours=24, id='new_plugins_check', name='Check for new official plugins')
        # Schedule a periodic forced update check for core (every hour).
        self.scheduler.add_job(self.check_for_forced_updates, 'interval', hours=1, id='forced_update_check', name='Check for forced core updates')
        # Schedule a periodic forced update check for plugins (every hour).
        self.scheduler.add_job(self.check_for_forced_plugin_updates, 'interval', hours=1, id='forced_plugin_update_check', name='Check for forced plugin updates')

    def ensure_directories(self):
        os.makedirs(self.UPDATE_DIR, exist_ok=True)
        os.makedirs(self.BACKUP_DIR, exist_ok=True)
        os.makedirs(os.path.dirname(self.LOG_PATH), exist_ok=True)

    # --- Manifest Fetching ---
    def get_core_manifest_remote(self):
        headers = {"PRIVATE-TOKEN": self.GITLAB_TOKEN}
        response = requests.get(self.CORE_MANIFEST_REMOTE_URL, headers=headers)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch core manifest: {response.status_code} - {response.text}")

    def get_plugin_manifest_remote(self, plugin_name):
        if not plugin_name:
            raise ValueError("Plugin name must be provided.")
        factory_manifest = self.plugin_manager.get_factory_manifest_by_name(plugin_name)
        if factory_manifest.get('repository') == 'official':
            plugin_manifest_url = "https://gitlab.com/api/v4/projects/sparrow-erp%2FCore/repository/files/manifest.json/raw?ref=main"
        else:
            plugin_manifest_url = factory_manifest.get('repository', '') + f"/{plugin_name}/manifest.json"
            if not plugin_manifest_url:
                raise Exception(f"Repository URL for {plugin_name} is missing or invalid in the factory manifest.")
        headers = {"PRIVATE-TOKEN": self.GITLAB_TOKEN}
        response = requests.get(plugin_manifest_url, headers=headers)
        if response.status_code == 200:
            return response.json()['plugins']
        else:
            raise Exception(f"Failed to fetch plugin manifest for {plugin_name}: {response.status_code} - {response.text}")

    def get_plugin_factory_manifest(self, plugin_name):
        if not plugin_name:
            raise ValueError("Plugin name must be provided.")
        plugin_manifest = self.plugin_manager.get_factory_manifest(plugin_name)
        if plugin_manifest.get('repository') == 'official':
            plugin_url = f"https://gitlab.com/api/v4/projects/sparrow-erp%2FCore/repository/files/manifest.json/raw?ref=main"
            headers = {"PRIVATE-TOKEN": self.GITLAB_TOKEN}
            response = requests.get(plugin_url, headers=headers)
            if response.status_code == 200:
                return response.json()
            else:
                raise Exception(f"Failed to fetch official plugin {plugin_name} manifest: {response.status_code} - {response.text}")
        repository_url = plugin_manifest.get('repository', '')
        if not repository_url:
            raise Exception(f"Repository URL missing for third-party plugin {plugin_name}.")
        response = requests.get(f"{repository_url}/plugins/{plugin_name}/factory_manifest.json", headers={"PRIVATE-TOKEN": self.GITLAB_TOKEN})
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch factory manifest for {plugin_name} from third-party repository: {response.status_code} - {response.text}")

    # --- Version Checking ---
    def get_current_version(self):
        core_manifest = self.plugin_manager.get_core_manifest()  # Local core manifest
        return core_manifest.get('version', 'Unknown')

    def get_latest_version(self):
        core_manifest = self.get_core_manifest_remote()
        return core_manifest['core'].get('current_version', 'Unknown')

    def get_plugin_latest_version(self, plugin_name):
        plugin_manifest = self.get_plugin_manifest_remote(plugin_name)
        return plugin_manifest[plugin_name].get('current_version', 'Unknown')

    def get_plugins_versions(self):
        plugins_versions = {}
        plugins = self.plugin_manager.get_all_plugins()
        for plugin in plugins:
            plugin_name = plugin["system_name"]
            plugin_versions = self.plugin_manager.get_plugin(plugin_name)
            plugins_versions[plugin_name] = plugin_versions.get("version", "Unknown")
        return plugins_versions

    def get_update_status(self):
        current_version = self.get_current_version()
        latest_version = self.get_latest_version()
        core_update_available = current_version < latest_version
        plugins_versions = self.get_plugins_versions()
        plugin_updates = []
        for plugin_name, plugin_version in plugins_versions.items():
            plugin_latest_version = self.get_plugin_latest_version(plugin_name)
            plugin_update_available = plugin_version < plugin_latest_version
            plugin_updates.append({
                "plugin_name": plugin_name,
                "current_version": plugin_version,
                "latest_version": plugin_latest_version,
                "update_available": plugin_update_available
            })
        results = {
            "core": {
                "current_version": current_version,
                "latest_version": latest_version,
                "update_available": core_update_available
            },
            "plugins": plugin_updates
        }
        return results

    # --- URL Conversion ---
    def convert_to_api_endpoint(self, download_url):
        api_prefix = "https://gitlab.com/api/v4/"
        if download_url.startswith(api_prefix):
            return download_url
        parsed = urlparse(download_url)
        path_parts = parsed.path.split('/')
        if len(path_parts) < 7 or path_parts[3] != '-' or path_parts[4] != 'raw':
            return download_url
        namespace = path_parts[1]
        project = path_parts[2]
        branch = path_parts[5]
        file_path = "/".join(path_parts[6:])
        project_identifier = quote(f"{namespace}/{project}", safe='')
        encoded_file_path = quote(file_path, safe='')
        return f"https://gitlab.com/api/v4/projects/{project_identifier}/repository/files/{encoded_file_path}/raw?ref={branch}"

    # --- Backup and Restore ---
    def backup(self, backup_name="whole_system_backup"):
        system_root = os.path.dirname(self.BACKUP_DIR)
        os.makedirs(self.BACKUP_DIR, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"{backup_name}_{timestamp}"
        backup_path = os.path.join(self.BACKUP_DIR, backup_filename)
        shutil.make_archive(backup_path, 'zip', system_root)
        return f"{backup_path}.zip"

    def restore_backup(self, backup_name, restore_to):
        backup_zip = os.path.join(self.BACKUP_DIR, f"{backup_name}.zip")
        if not os.path.exists(backup_zip):
            raise Exception(f"Backup {backup_zip} not found.")
        os.makedirs(restore_to, exist_ok=True)
        with zipfile.ZipFile(backup_zip, 'r') as zip_ref:
            zip_ref.extractall(restore_to)

    # --- Update Installation ---
    def download_update(self, url, save_path):
        """Download the update from the given URL with authentication."""
        headers = {"PRIVATE-TOKEN": self.GITLAB_TOKEN}
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            with open(save_path, 'wb') as f:
                f.write(response.content)
        else:
            raise Exception(f"Failed to download update from {url}: {response.status_code}")

    def apply_zip(self, zip_path, target_path):
        if os.path.exists(zip_path):
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(target_path)
        else:
            raise Exception(f"Update file not found: {zip_path}")

    def run_update_instructions(self, script_path):
        try:
            print(f"Executing update instructions from {script_path}...")
            subprocess.run(["python", script_path], check=True)
            print("Update instructions executed successfully.")
        except subprocess.CalledProcessError as e:
            raise Exception(f"Running update instructions failed: {e}")

    def apply_update(self, update_type, plugin_name=None):
        backup_archive = None
        # The whole system is defined as the parent directory of BACKUP_DIR (e.g., "app")
        system_root = os.path.dirname(self.BACKUP_DIR)
        try:
            print("Creating whole system backup...")
            backup_archive = self.backup()  # Whole system backup
            print(f"Whole system backup created: {backup_archive}")

            if update_type == "core":
                print("Fetching core manifest...")
                core_manifest = self.get_core_manifest_remote()
                print("Downloading core update...")
                download_url = core_manifest['core'].get('download_url')
                if not download_url:
                    raise Exception("No download URL for core update.")
                download_url = self.convert_to_api_endpoint(download_url)
                zip_path = os.path.join(self.UPDATE_DIR, "core_update.zip")
                self.download_update(download_url, zip_path)
                print("Applying core update...")
                self.apply_zip(zip_path, system_root)

                # Update the local manifest's version field
                manifest_path = os.path.join(system_root, "config", "manifest.json")
                new_version = core_manifest['core'].get('current_version')
                if os.path.exists(manifest_path):
                    with open(manifest_path, 'r') as f:
                        manifest_data = json.load(f)
                else:
                    manifest_data = {}
                manifest_data['version'] = new_version
                with open(manifest_path, 'w') as f:
                    json.dump(manifest_data, f, indent=4)
                print(f"Manifest version updated to {new_version}.")

                update_script = os.path.join(system_root, "update_instructions.py")
                if os.path.exists(update_script):
                    self.run_update_instructions(update_script)
                print("Core update completed.")

            elif update_type == "plugin" and plugin_name:
                print(f"Fetching plugin manifest for {plugin_name}...")
                plugin_manifest = self.get_plugin_manifest_remote(plugin_name)
                print(f"Downloading plugin update for {plugin_name}...")
                download_url = plugin_manifest.get('download_url')
                if not download_url:
                    raise Exception(f"No download URL for plugin {plugin_name} update.")
                download_url = self.convert_to_api_endpoint(download_url)
                zip_path = os.path.join(self.UPDATE_DIR, f"{plugin_name}_update.zip")
                self.download_update(download_url, zip_path)
                plugin_path = os.path.join(self.PLUGIN_PATH, plugin_name)
                print(f"Applying plugin update for {plugin_name}...")
                self.apply_zip(zip_path, plugin_path)
                update_script = os.path.join(plugin_path, "update_instructions.py")
                if os.path.exists(update_script):
                    self.run_update_instructions(update_script)
                print(f"{plugin_name} update completed.")

            else:
                raise Exception("Invalid update type.")

            print("Update applied successfully.")

        except Exception as e:
            print(f"Update failed: {str(e)}")
            if backup_archive:
                print("Rolling back to the previous whole system backup...")
                backup_name = os.path.basename(backup_archive).replace('.zip', '')
                self.restore_backup(backup_name, system_root)
                print("System restored from backup.")
            raise

    def log_update(self, update_type, name, old_version, new_version):
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "update_type": update_type,
            "name": name,
            "old_version": old_version,
            "new_version": new_version
        }
        with open(self.LOG_PATH, 'a') as log_file:
            json.dump(log_entry, log_file)
            log_file.write("\n")

    def schedule_update(self, update_type, scheduled_time, plugin_name=None):
        run_date = datetime.strptime(scheduled_time, "%Y-%m-%d %H:%M:%S")
        if update_type == "core":
            self.scheduler.add_job(self.apply_update, 'date', run_date=run_date, args=['core'])
        elif update_type == "plugin" and plugin_name:
            self.scheduler.add_job(self.apply_update, 'date', run_date=run_date, args=['plugin', plugin_name])
        else:
            raise Exception(f"Invalid update type: {update_type}")
        print(f"Update scheduled for {update_type} at {run_date}")

    def get_changelog_for_plugin(self, plugin_name):
        try:
            plugin_manifest = self.get_plugin_manifest_remote(plugin_name)
            return plugin_manifest[plugin_name].get('changelog', 'No changelog available.')
        except Exception as e:
            print(f"Failed to fetch changelog for plugin {plugin_name}: {e}")
            return 'No changelog available.'

    def get_changelog_for_core(self):
        try:
            core_manifest = self.get_core_manifest_remote()
            return core_manifest['core'].get('changelog', 'No changelog available.')
        except Exception as e:
            print(f"Failed to fetch changelog for core module: {e}")
            return 'No changelog available.'

    def get_remote_plugin_list(self):
        headers = {"PRIVATE-TOKEN": self.GITLAB_TOKEN}
        response = requests.get("https://gitlab.com/api/v4/projects/sparrow-erp%2FCore/repository/files/plugins?ref=main", headers=headers)
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch plugin list: {response.status_code} - {response.text}")

    def install_plugin(self, plugin_name):
        plugin_manifest = self.get_plugin_manifest_remote(plugin_name)
        download_url = plugin_manifest.get('download_url')
        if download_url:
            zip_path = os.path.join(self.PLUGIN_PATH, f"{plugin_name}_update.zip")
            self.download_update(download_url, zip_path)
            self.apply_zip(zip_path, os.path.join(self.PLUGIN_PATH, plugin_name))
            print(f"Plugin {plugin_name} installed successfully.")
        else:
            print(f"Download URL not found for plugin {plugin_name}.")
            raise Exception(f"No download URL found for plugin {plugin_name}")

    def check_and_download_new_plugins(self):
        print("Checking for new plugins...")
        remote_plugins = self.get_remote_plugin_list()
        installed_plugins = [plugin["system_name"] for plugin in self.plugin_manager.get_all_plugins()]
        for plugin_name in remote_plugins:
            if plugin_name not in installed_plugins:
                print(f"New plugin found: {plugin_name}. Downloading and installing...")
                self.install_plugin(plugin_name)
            else:
                print(f"Plugin {plugin_name} is already installed.")

    # --- Forced Update Check for Core ---
    def check_for_forced_updates(self):
        try:
            core_manifest = self.get_core_manifest_remote()
            force_update = core_manifest.get('core', {}).get('force_update', False)
            if force_update:
                if not self.scheduler.get_job("forced_core_update"):
                    now = datetime.now()
                    next_3am = now.replace(hour=3, minute=0, second=0, microsecond=0)
                    if next_3am <= now:
                        next_3am += timedelta(days=1)
                    print(f"Force update flag detected in core manifest. Scheduling core update at {next_3am}")
                    self.scheduler.add_job(self.apply_update, 'date', run_date=next_3am, args=['core'], id="forced_core_update", name="Forced Core Update")
            else:
                if self.scheduler.get_job("forced_core_update"):
                    self.scheduler.remove_job("forced_core_update")
        except Exception as e:
            print(f"Error checking forced updates: {e}")

    # --- Forced Update Check for Plugins ---
    def check_for_forced_plugin_updates(self):
        try:
            installed_plugins = [plugin["system_name"] for plugin in self.plugin_manager.get_all_plugins()]
            for plugin_name in installed_plugins:
                try:
                    plugin_manifest = self.get_plugin_manifest_remote(plugin_name)
                    force_update = plugin_manifest.get(plugin_name, {}).get('force_update', False)
                    job_id = f"forced_plugin_update_{plugin_name}"
                    if force_update:
                        if not self.scheduler.get_job(job_id):
                            now = datetime.now()
                            next_3am = now.replace(hour=3, minute=0, second=0, microsecond=0)
                            if next_3am <= now:
                                next_3am += timedelta(days=1)
                            print(f"Force update flag detected for plugin {plugin_name}. Scheduling update at {next_3am}")
                            self.scheduler.add_job(self.apply_update, 'date', run_date=next_3am, args=['plugin', plugin_name], id=job_id, name=f"Forced Plugin Update {plugin_name}")
                    else:
                        if self.scheduler.get_job(job_id):
                            self.scheduler.remove_job(job_id)
                except Exception as e:
                    print(f"Error checking forced update for plugin {plugin_name}: {e}")
        except Exception as e:
            print(f"Error checking forced plugin updates: {e}")


class Plugin:
    def __init__(self, system_name, plugins_dir='app/plugins'):
        self.system_name = system_name
        self.plugins_dir = plugins_dir
        self.plugin_path = os.path.join(self.plugins_dir, self.system_name)
        self.manifest_path = os.path.join(self.plugin_path, 'manifest.json')
        self.manifest = self.get_manifest()

    def get_manifest(self):
        """Load the plugin's manifest file."""
        manifest_path = os.path.join(self.plugins_dir, self.system_name, 'manifest.json')
        if os.path.exists(manifest_path):
            try:
                with open(manifest_path, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError as e:
                print(f"Error decoding JSON: {e}")
        return None

    def save_manifest(self):
        """Save the current state of the plugin's manifest."""
        manifest_path = os.path.join(self.plugins_dir, self.system_name, 'manifest.json')
        with open(manifest_path, 'w') as f:
            json.dump(self.manifest, f, indent=4)

    def install(self):
        """Install the plugin using the factory manifest located in the plugin folder."""
        plugin_path = os.path.join(self.plugins_dir, self.system_name)
        
        # Ensure the plugin directory exists
        if not os.path.exists(plugin_path):
            os.makedirs(plugin_path)

        # Check if manifest already exists (in case the plugin was previously installed)
        manifest_path = os.path.join(plugin_path, 'manifest.json')
        if os.path.exists(manifest_path):
            print("Plugin is already installed")
            return False, "Plugin is already installed."

        # Load the factory manifest from the plugin folder
        factory_manifest_path = os.path.join(plugin_path, 'factory_manifest.json')
        if not os.path.exists(factory_manifest_path):
            print("Factory Manifest not found")
            return False, "Factory manifest not found."

        # Read the factory manifest
        with open(factory_manifest_path, 'r') as f:
            factory_manifest = json.load(f)

        # Initialize the plugin manifest from the factory manifest
        self.manifest = factory_manifest

        # Set plugin as enabled after installation (you can set this to False if you prefer to enable it later)
        self.manifest['enabled'] = False

        # Save the plugin manifest to the plugin directory
        self.save_manifest()

        # Additional installation steps (e.g., database tables) can be added here
        print("Installed Successfully")
        return True, f"{self.system_name} installed successfully."


    def uninstall(self):
        """Uninstall the plugin by removing its manifest file."""
        if not os.path.exists(self.plugin_path):
            return False, "Plugin directory not found."

        # Remove the manifest file (keeping plugin content intact)
        try:
            if os.path.exists(self.manifest_path):
                os.remove(self.manifest_path)
                print(f"Removed manifest for plugin: {self.system_name}")

            return True, f"{self.system_name} uninstalled successfully."

        except Exception as e:
            print(f"Error uninstalling plugin: {e}")
            return False, f"Error uninstalling plugin: {e}"

    def enable(self):
        """Enable the plugin by setting 'enabled' to True and saving the manifest."""
        if not self.manifest:
            return False, "Manifest not found."
        
        self.manifest['enabled'] = True
        self.save_manifest()
        return True, f"{self.system_name} enabled successfully."

    def disable(self):
        """Disable the plugin by setting 'enabled' to False and saving the manifest."""
        if not self.manifest:
            return False, "Manifest not found."
        
        self.manifest['enabled'] = False
        self.save_manifest()
        return True, f"{self.system_name} disabled successfully."

    def get_settings(self):
        """Return the settings of the plugin, or an empty dictionary if not defined."""
        if not self.manifest or 'settings' not in self.manifest:
            return {}
        return self.manifest['settings']

    def save_settings(self, settings):
        """Save the provided settings to the plugin's manifest."""
        if not self.manifest:
            return False, "Manifest not found."
        
        self.manifest['settings'] = settings
        self.save_manifest()
        return True, "Settings saved successfully."

    def update_setting(self, setting_key, setting_value):
        """Update a setting if it's editable."""
        if not self.manifest or 'settings' not in self.manifest:
            return False, "Settings not found in the manifest."

        settings = self.manifest['settings']
        if setting_key not in settings:
            return False, f"Setting {setting_key} not found."

        setting = settings[setting_key]
        if not setting.get('editable', False):
            return False, f"Setting {setting_key} is not editable."

        setting['value'] = setting_value
        self.save_manifest()
        return True, f"Setting {setting_key} updated successfully."

    @staticmethod
    def get_factory_manifest(plugin_path):
        """Load the factory manifest data from factory_manifest.json."""
        factory_manifest_path = os.path.join(plugin_path, "factory_manifest.json")
        if os.path.exists(factory_manifest_path):
            try:
                with open(factory_manifest_path, "r") as factory_manifest_file:
                    return json.load(factory_manifest_file)
            except (json.JSONDecodeError, IOError) as e:
                print(f"Error reading factory_manifest.json for {plugin_path}: {e}")
        return None

class PluginManager:
    def __init__(self, plugins_dir='plugins'):
        # Use the absolute path to avoid confusion
        app_root = os.path.abspath(os.path.dirname(__file__))  # Directory of this file (sparrow-erp/app)
        self.plugins_dir = os.path.join(app_root, plugins_dir)
        self.config_dir = os.path.join(app_root, 'config')
        self.plugins = self.load_plugins()  # Load all plugins on initialization

    def get_all_plugins(self):
        """Returns a list of all installed plugins along with their details."""
        plugins = []
        if not os.path.exists(self.plugins_dir):
            print(f"Plugins folder does not exist: {self.plugins_dir}")
            return plugins

        print(f"Scanning plugins in: {self.plugins_dir}")
        for plugin_name in os.listdir(self.plugins_dir):
            plugin_path = os.path.join(self.plugins_dir, plugin_name)

            if not os.path.isdir(plugin_path) or plugin_name.startswith("__"):
                continue
            # Attempt to get the plugin's factory manifest
            factory_manifest = self.get_factory_manifest(plugin_path)
            # Attempt to get the plugin's regular manifest
            manifest = self.get_plugin_manifest(plugin_path)

            # Initialize plugin data with the factory manifest details
            if factory_manifest:
                icon_filename = factory_manifest.get("icon", "default-icon.png")
                plugin_data = {
                    "name": factory_manifest.get("name", plugin_name),
                    "description": factory_manifest.get("description", "No description available."),
                    "icon": f"{icon_filename}",
                    "system_name": factory_manifest.get("system_name", plugin_name.lower()),
                    "version": factory_manifest.get("version", "Unknown"),
                    "update_available": factory_manifest.get("update_available", False)  # Ensure update flag here
                }
            else:
                print(f"No factory_manifest.json found for: {plugin_name}")
                plugin_data = {
                    "name": plugin_name,
                    "description": "No description available.",
                    "icon": "/app/plugins/default-icon.png",  # Default icon if no factory manifest found
                    "system_name": plugin_name.lower(),
                    "version": "Unknown",
                    "update_available": False  # Default flag for update availability
                }

            # Check if the plugin is installed
            plugin_data["installed"] = os.path.exists(os.path.join(plugin_path, 'manifest.json'))

            # If installed, check if it's enabled
            if plugin_data["installed"]:
                if manifest:
                    plugin_data["enabled"] = manifest.get("enabled", False)
                else:
                    plugin_data["enabled"] = False  # Default to False if manifest.json is missing
            else:
                plugin_data["enabled"] = False  # Default to False if not installed

            plugins.append(plugin_data)

        return plugins

    def get_factory_manifest(self, plugin_path):
        """Retrieve the factory manifest for a plugin."""
        factory_manifest_path = os.path.join(plugin_path, 'factory_manifest.json')
        if os.path.exists(factory_manifest_path):
            with open(factory_manifest_path, 'r') as f:
                return json.load(f)
        return None

    def get_factory_manifest_by_name(self, plugin_name):
        """Retrieve the factory manifest for a plugin."""
        factory_manifest_path = os.path.join(self.plugins_dir, plugin_name, 'factory_manifest.json')
        if os.path.exists(factory_manifest_path):
            with open(factory_manifest_path, 'r') as f:
                return json.load(f)
        return None

    def get_plugin_manifest(self, plugin_system_name):
        """Retrieve the manifest for a plugin."""
        # Construct the full path to the plugin directory
        plugin_path = os.path.join(self.plugins_dir, plugin_system_name)
        manifest_path = os.path.join(plugin_path, 'manifest.json')

        if os.path.exists(manifest_path):
            with open(manifest_path, 'r') as f:
                return json.load(f)
        return None



    def get_plugin(self, system_name):
        """Get a specific plugin by its system name (UID)."""
        plugin = Plugin(system_name)
        return plugin.get_manifest()

    def update_plugin_settings(self, plugin_system_name, form_data):
        """Update the plugin settings from the form data."""
        plugin_path = os.path.join(self.plugins_dir, plugin_system_name)
        manifest_path = os.path.join(plugin_path, 'manifest.json')

        if os.path.exists(manifest_path):
            with open(manifest_path, 'r') as f:
                manifest = json.load(f)

            # Update the settings based on the form data
            for key, value in form_data.items():
                # Ensure the setting exists in the manifest and update it
                if key in manifest.get('settings', {}):
                    manifest['settings'][key]['value'] = value

            # Save the updated manifest
            with open(manifest_path, 'w') as f:
                json.dump(manifest, f, indent=4)
            
    
        else:
            print(f"Manifest not found for {plugin_system_name}")

    def check_dependencies(self, system_name):
        """
        Checks whether the specified plugin has any missing dependencies.
        Returns a tuple (can_enable, missing_dependency).
        - can_enable (bool): True if the plugin can be enabled, False otherwise.
        - missing_dependency (str or None): The name of a missing dependency, or None if all dependencies are satisfied.
        """
        plugins = self.load_plugins()
    
        if system_name not in plugins:
            raise ValueError(f"Plugin {system_name} not found.")
        
        plugin_manifest = plugins[system_name]
     
        dependencies = plugin_manifest.get('dependencies', [])

        # If there are no dependencies, we can enable the plugin
        if not dependencies:
            print("no dependencies")
            return True, None
        
        # Check if all dependencies are met
        for dependency in dependencies:
            self.install_plugin(dependency)
            self.enable_plugin(dependency)
        
        return True, None

    def get_dependents(self, plugin_name):
        """Find which plugins depend on a given plugin"""
        dependents = []
        for plugin, manifest in self.plugins.items():
            dependencies = manifest.get('dependencies', [])
            if plugin_name in dependencies:
                dependents.append(plugin)
        return dependents

    def load_plugins(self):
        """
        Loads all plugins from the plugins_dir, reading their manifest.json or 
        factory_manifest.json files and returning a dictionary of plugin data.
        """
        plugins = {}

        # Check if the plugins directory exists
        if not os.path.exists(self.plugins_dir):
            print(f"Plugins directory not found: {self.plugins_dir}")
            return plugins

        # Iterate through each folder in the plugins directory
        for plugin_folder in os.listdir(self.plugins_dir):
            plugin_path = os.path.join(self.plugins_dir, plugin_folder)

            # Skip if it's not a directory
            if not os.path.isdir(plugin_path):
                continue

            # Paths for the plugin's manifest files
            manifest_path = os.path.join(plugin_path, 'manifest.json')
            factory_manifest_path = os.path.join(plugin_path, 'factory_manifest.json')

            # Load the manifest if it exists; fallback to factory manifest
            try:
                if os.path.exists(manifest_path):
                    with open(manifest_path, 'r') as f:
                        plugin_manifest = json.load(f)
                        plugin_manifest['installed'] = True  # Mark as installed
                        plugins[plugin_folder] = plugin_manifest
                elif os.path.exists(factory_manifest_path):
                    with open(factory_manifest_path, 'r') as f:
                        factory_manifest = json.load(f)
                        factory_manifest['installed'] = False  # Mark as not installed
                        plugins[plugin_folder] = factory_manifest
                else:
                    print(f"No manifest found for plugin: {plugin_folder}")
            except (json.JSONDecodeError, IOError) as e:
                print(f"Error reading manifest for {plugin_folder}: {e}")
                continue

        return plugins

    def register_admin_routes(self, app):
        """
        Dynamically register admin routes for all plugins that define them.
        """
        for plugin_name, plugin_manifest in self.plugins.items():
            try:
                # Dynamically import the plugin's module
                module = importlib.import_module(f"app.plugins.{plugin_name}.routes")

                # Check if the plugin defines the `register_admin_routes` function
                if hasattr(module, 'register_admin_routes'):
                    module.register_admin_routes(app)  # Register the admin routes
                    print(f"Admin routes registered for plugin: {plugin_name}")
                else:
                    print(f"Plugin {plugin_name} does not define 'register_admin_routes'.")
            except ModuleNotFoundError:
                print(f"Plugin module not found: {plugin_name}")
            except Exception as e:
                print(f"Error registering admin routes for plugin {plugin_name}: {e}")

    def install_plugin(self, plugin_name):
        """Install a plugin and its dependencies."""
        if plugin_name not in self.plugins:
            raise ValueError(f"Plugin {plugin_name} not found")

        plugin_manifest = self.plugins[plugin_name]
        
        # Check dependencies
        can_enable, missing_dependency = self.check_dependencies(plugin_name)
        
        if missing_dependency:
            # Install dependencies first (but do not enable them)
            for dep in missing_dependency:
                if dep not in self.plugins:
                    raise ValueError(f"Dependency {dep} not found")
                # Install the dependency without enabling it
                self.install_plugin(dep)
        
        # Install the plugin itself
        plugin = Plugin(plugin_name)
        install_status, install_message = plugin.install()

        if not install_status:
            raise Exception(f"Plugin installation failed: {install_message}")
        
        # Run dependency handler after installation
        try:
            print("Running dependency handler after installing plugin...")
            subprocess.check_call([sys.executable, "dependency_handler.py"])
        except subprocess.CalledProcessError as e:
            print(f"Dependency handler failed: {e}")
            raise
        
        # Mark the plugin as installed (not enabled)
        plugin_manifest['enabled'] = False
        plugin_manifest['update_available'] = False  # Mark as updated after installation
        plugin.save_manifest()  # Save updated manifest to reflect the changes

        print(f"Plugin {plugin_name} installed successfully.")
        return True, f"Plugin {plugin_name} installed successfully."


    def uninstall_plugin(self, system_name):
        """
        Uninstalls a plugin by removing its manifest file.
        - Disables the plugin if it is enabled.
        - Disables any dependent plugins before uninstalling.
        - Removes the plugin's manifest file if no other plugin depends on it.
        """
        # Ensure the plugin exists first
        plugins = self.load_plugins()
        if system_name not in plugins:
            raise ValueError(f"Plugin {system_name} not found.")
        
        # Get the plugin's manifest
        plugin_manifest = plugins[system_name]
        
        # Disable dependent plugins first
        dependencies = self.get_dependents(system_name)
        for dependency in dependencies:
            # Disable dependencies if enabled
            if self.is_plugin_enabled(dependency):
                self.disable_plugin(dependency)
        
        # Now that dependencies are disabled, disable the main plugin
        if self.is_plugin_enabled(system_name):
            self.disable_plugin(system_name)

        # Path to the plugin's manifest file
        plugin_manifest_path = os.path.join(self.plugins_dir, system_name, 'manifest.json')

        # Remove the plugin's manifest file
        if os.path.exists(plugin_manifest_path):
            os.remove(plugin_manifest_path)
            print(f"Plugin {system_name} manifest file removed successfully.")
        else:
            raise FileNotFoundError(f"Manifest file for {system_name} not found.")


    def is_plugin_enabled(self, system_name):
        """
        Checks if the plugin is enabled based on its manifest file.
        Returns True if the plugin is enabled, False otherwise.
        """
        plugins = self.load_plugins()
        if system_name not in plugins:
            raise ValueError(f"Plugin {system_name} not found.")
        
        plugin_manifest = plugins[system_name]
        # Check the 'enabled' status in the plugin's manifest
        return plugin_manifest.get('enabled', False)

    def enable_plugin(self, system_name):
        """Enable a plugin, ensuring dependencies are installed and enabled."""
        plugin_path = os.path.join(self.plugins_dir, system_name)
        plugin_manifest_path = os.path.join(plugin_path, 'manifest.json')

        if not os.path.exists(plugin_manifest_path):
            return False, f"{system_name} is not installed."

        # Load the plugin's manifest
        with open(plugin_manifest_path, 'r') as f:
            plugin_manifest = json.load(f)

        # If the plugin is already enabled, return early
        if plugin_manifest.get('enabled', False):
            return True, f"{system_name} is already enabled."

        # Check dependencies of the plugin
        can_enable, missing_dependency = self.check_dependencies(system_name)
        if not can_enable and missing_dependency:
            # Install and enable the missing dependency
            install_status, message = self.install_plugin(missing_dependency)
            if not install_status:
                return False, f"Cannot enable {system_name}: {message}"

            # Enable the dependency
            self.enable_plugin(missing_dependency)

        # Now enable the plugin itself
        plugin_manifest['enabled'] = True
        # Update the 'update_available' flag to False (plugin is now enabled)
        plugin_manifest['update_available'] = False

        # Save the updated manifest back
        with open(plugin_manifest_path, 'w') as f:
            json.dump(plugin_manifest, f, indent=4)

        # Run dependency handler after enabling
        try:
            print("Running dependency handler after enabling plugin...")
            subprocess.check_call([sys.executable, "dependency_handler.py"])
        except subprocess.CalledProcessError as e:
            print(f"Dependency handler failed: {e}")
            raise

        print(f"{system_name} enabled successfully.")
        return True, f"{system_name} enabled successfully."

    def disable_plugin(self, system_name):
        """Disable a plugin and its dependents."""
        plugin_path = os.path.join(self.plugins_dir, system_name)
        plugin_manifest_path = os.path.join(plugin_path, 'manifest.json')

        if not os.path.exists(plugin_manifest_path):
            return False, f"{system_name} is not installed."

        # Load the plugin's manifest
        with open(plugin_manifest_path, 'r') as f:
            plugin_manifest = json.load(f)

        # Disable the plugin itself
        plugin_manifest['enabled'] = False
        # Mark the plugin as 'update_available' if needed, depending on your use case
        plugin_manifest['update_available'] = True

        # Save the updated manifest back
        with open(plugin_manifest_path, 'w') as f:
            json.dump(plugin_manifest, f, indent=4)
        print(f"{system_name} has been disabled.")

        # Find and disable dependents
        dependents = self.get_dependents(system_name)
        for dependent in dependents:
            dependent_plugin_path = os.path.join(self.plugins_dir, dependent)
            dependent_plugin_manifest_path = os.path.join(dependent_plugin_path, 'manifest.json')

            if os.path.exists(dependent_plugin_manifest_path):
                with open(dependent_plugin_manifest_path, 'r') as dep_f:
                    dep_manifest = json.load(dep_f)

                if dep_manifest.get('enabled', False):
                    dep_manifest['enabled'] = False
                    # Mark as 'update_available' for dependents as well
                    dep_manifest['update_available'] = True

                    with open(dependent_plugin_manifest_path, 'w') as dep_f:
                        json.dump(dep_manifest, dep_f, indent=4)
                    print(f"Disabled dependent plugin: {dependent}")

        return True, f"{system_name} and its dependents have been disabled."


    def get_enabled_plugins(self):
        """Retrieve all enabled plugins with their name and system_name."""
        plugins = []
        for plugin_folder in os.listdir(self.plugins_dir):
            plugin_path = os.path.join(self.plugins_dir, plugin_folder)
            if os.path.isdir(plugin_path):
                plugin = Plugin(plugin_folder)
                plugin_data = plugin.get_manifest()
                if plugin_data and plugin_data.get("enabled", False):
                    plugins.append({
                        "name": plugin_data.get("name", plugin_folder),  # Default to folder name if missing
                        "system_name": plugin_folder  # Use folder name as system_name
                    })
        return plugins


    def get_core_manifest(self):
        """Load the core module's manifest file (config/manifest.json)."""
        core_manifest_path = os.path.join(self.config_dir, 'manifest.json')
        
        if os.path.exists(core_manifest_path):
            with open(core_manifest_path, 'r') as f:
                try:
                    core_manifest = json.load(f)
                    return core_manifest
                except json.JSONDecodeError:
                    print(f"Error reading core manifest at {core_manifest_path}.")
        else:
            print(f"Core manifest not found at {core_manifest_path}.")
        return None

    def get_core_manifest_path(self):
        """Load the core module's manifest file (config/manifest.json)."""
        core_manifest_path = os.path.join(self.config_dir, 'manifest.json')
        
        if os.path.exists(core_manifest_path):
            return core_manifest_path
        else:
            print(f"Core manifest not found at {core_manifest_path}.")
        return core_manifest_path

    def update_plugin_manifest(self, plugin_name, update_flag):
        """Update the 'update_available' flag in the plugin's manifest."""
        plugin_manifest = self.get_plugin_manifest(plugin_name)
        if plugin_manifest:
            plugin_manifest['update_available'] = update_flag
            self.save_plugin_manifest(plugin_name, plugin_manifest)

    def save_plugin_manifest(self, plugin_name, plugin_manifest):
        """Save the updated plugin manifest to the plugin directory."""
        plugin_path = os.path.join(self.plugins_dir, plugin_name, 'manifest.json')
        with open(plugin_path, 'w') as f:
            json.dump(plugin_manifest, f, indent=4)
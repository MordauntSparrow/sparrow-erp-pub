from flask import Flask, session
from werkzeug.serving import make_server
import threading
import os
from .routes import website_public_routes, website_admin_routes, register_plugin_routes
import json
from ...objects import PluginManager

def create_website_app(plugins_dir=None):
    """
    Creates and configures the Flask app for the website module.
    Dynamically loads plugin routes if they exist.
    """
    if plugins_dir is None:
        plugins_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

    app = Flask(__name__,
                static_url_path='/static',
                static_folder=os.path.join(os.path.dirname(__file__), '../../static'))
    app.register_blueprint(website_public_routes, url_prefix="/")

    # Load website module manifest
    manifest_path = os.path.join(os.path.dirname(__file__), 'manifest.json')
    with open(manifest_path, 'r') as f:
        manifest = json.load(f)

    control_mode = manifest.get('control_mode', 'erp')

    # Dynamic route registration based on control mode
    if control_mode == 'erp':
        register_plugin_routes(app, plugins_dir)
    elif control_mode == 'moderate':
        print("Moderate mode: Developers can manually add routes.")
    elif control_mode == 'independent':
        print("Independent mode: Website module provides no predefined routes.")

    return app


class WebsiteServer:
    """
    Manages the website Flask application lifecycle (start/stop).
    """
    def __init__(self, port=80, plugins_dir=os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))):
        self.port = port
        self.plugins_dir = plugins_dir
        self.app = create_website_app(plugins_dir)
        self.server = None
        self.thread = None

    def start(self):
        """
        Starts the website server in a separate thread.
        """
        def _run():
            self.server = make_server("0.0.0.0", self.port, self.app)
            self.server.serve_forever()

        print(f"Starting website server on port {self.port}...")
        self.thread = threading.Thread(target=_run)
        self.thread.daemon = True
        self.thread.start()
        print("Website server started.")

    def stop(self):
        """
        Stops the website server gracefully.
        """
        if self.server:
            print("Stopping website server...")
            self.server.shutdown()
            self.thread.join()
            print("Website server stopped.")
        else:
            print("Website server is not running.")

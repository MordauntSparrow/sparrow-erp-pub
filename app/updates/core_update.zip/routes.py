from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify, send_from_directory
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))  # Add current directory to path
from werkzeug.utils import secure_filename
import json
from app.objects import PluginManager  # Import PluginManager from objects.py
from app.objects import UpdateManager
import threading


PLUGINS_FOLDER = os.path.join(os.path.dirname(__file__), "plugins")

# Create a blueprint for routes
routes = Blueprint('routes', __name__)

# Simulated user database for placeholder testing
SIMULATED_USERS = {
    "admin": {
        "username": "admin",
        "password": "password",
        "first_name": "Admin",
        "last_name": "User",
        "theme": "default"
    }
}

@routes.route('/login', methods=['GET', 'POST'])
def login():
    # Load site settings from core manifest and store in session
    plugin_manager = PluginManager(PLUGINS_FOLDER)
    core_manifest = plugin_manager.get_core_manifest()
    
    site_settings = core_manifest.get('site_settings', {
        'company_name': 'Sparrow ERP',
        'branding': 'name',
        'logo_path': ''
    })
    session['site_settings'] = site_settings
    session['core_manifest'] = core_manifest
    if request.method == 'POST':
        # Simulated user authentication
        username = request.form['username']
        password = request.form['password']

        user = SIMULATED_USERS.get(username)  # Fetch user from simulated database
        if user and user['password'] == password:
            # Simulate successful login with user details
            session['logged_in'] = True
            session['username'] = user['username']
            session['first_name'] = user['first_name']
            session['last_name'] = user['last_name']
            session['theme'] = user['theme']
            flash(f"Welcome back, {user['first_name']}!", 'success')
            return redirect(url_for('routes.dashboard'))
        else:
            flash('Invalid credentials.', 'error')


    # Render the login template with site branding and settings
    return render_template('login.html', site_settings=site_settings)



@routes.route('/')
def dashboard():
    if session.get('logged_in'):  # Check if the user is logged in
        # Simulated user details pulled from the session
        user = {
            'username': session.get('username', 'guest'),
            'first_name': session.get('first_name', 'Guest'),
            'last_name': session.get('last_name', 'User'),
            'theme': session.get('theme', 'default')
        }

        # Load plugins dynamically
        plugin_manager = PluginManager(PLUGINS_FOLDER)
        plugins = plugin_manager.get_enabled_plugins()

        # Load core manifest to get version
        core_manifest = plugin_manager.get_core_manifest()
        core_version = core_manifest.get('version', '0.0.1') if core_manifest else '0.0.1'

        return render_template(
            'dashboard.html',
            plugins=plugins,
            config=core_manifest,
            user=user,
            core_version=core_version
        )
    else:
        flash('You need to log in first!', 'warning')
        return redirect(url_for('routes.login'))




@routes.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('routes.login'))


# Plugins route to view and manage plugins
@routes.route('/plugins')
def plugins():
    if 'logged_in' in session and session['logged_in']:
        # Get list of available plugins using PluginManager
        plugin_manager = PluginManager(PLUGINS_FOLDER)
        plugins = plugin_manager.get_all_plugins()
        return render_template('plugins.html', plugins=plugins, config = plugin_manager.get_core_manifest())
    else:
        flash('You need to log in first!', 'warning')
        return redirect(url_for('routes.login'))

@routes.route('/version', methods=['GET', 'POST'])
def version():
    if 'logged_in' in session and session['logged_in']:
        update_manager = UpdateManager()
        plugin_manager = PluginManager()
        
        # Handle POST requests
        if request.method == 'POST':
            update_type = request.form['update_type']  # 'core' or 'plugin'
            plugin_name = request.form.get('plugin_name')  # Only needed if update_type is 'plugin'

            # Determine if it's an immediate update or a scheduled update
            scheduled_time = request.form.get('scheduled_time')  # Optional
            if scheduled_time:
                # Scheduled update
                update_manager.schedule_update(update_type, scheduled_time, plugin_name)
                flash(f"Update scheduled for {update_type} at {scheduled_time}", 'success')
            else:
                # Immediate update
                try:
                    update_manager.apply_update(update_type, plugin_name)
                    flash(f"{update_type.capitalize()} updated successfully.", 'success')
                except Exception as e:
                    flash(f"Error during {update_type} update: {str(e)}", 'danger')

            return redirect(url_for('routes.version'))

        # Get version information
        current_version = update_manager.get_current_version()
        latest_version = update_manager.get_latest_version()

        if current_version is None or latest_version is None:
            return jsonify({"error": "Current or latest version not found."}), 500

        core_update_available = current_version < latest_version
        update_status = update_manager.get_update_status()

        core_changelog = update_manager.get_changelog_for_core()
        plugin_changelogs = {plugin['plugin_name']: update_manager.get_changelog_for_plugin(plugin['plugin_name']) for plugin in update_status['plugins']}

        core_manifest = update_manager.get_core_manifest_remote()

        return render_template('version_checker.html', 
                               config=plugin_manager.get_core_manifest(),
                               current_version=current_version, 
                               latest_version=latest_version, 
                               update_available=core_update_available, 
                               plugins=update_status['plugins'], 
                               core_changelog=core_changelog,
                               plugin_changelogs=plugin_changelogs)
    else:
        flash('You need to log in first!', 'warning')
        return redirect(url_for('routes.login'))



STATIC_UPLOAD_FOLDER = os.path.join('app', 'static', 'uploads')  # Shared uploads folder
os.makedirs(STATIC_UPLOAD_FOLDER, exist_ok=True)

# Allowed file extensions
ALLOWED_LOGO_EXTENSIONS = {'png', 'jpg', 'jpeg', 'svg'}
ALLOWED_CSS_EXTENSIONS = {'css'}

# Utility to validate file extensions
def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

# Core Module Settings Route
@routes.route('/core/settings', methods=['GET', 'POST'])
def core_module_settings():
    if 'logged_in' in session and session['logged_in']:
        # Initialize PluginManager and get core manifest path
        plugin_manager = PluginManager(PLUGINS_FOLDER)
        manifest_path = plugin_manager.get_core_manifest_path()

        # Default configuration structure
        default_config = {
            "theme_settings": {
                "theme": "default",
                "custom_css_path": ""
            },
            "site_settings": {
                "company_name": "Sparrow ERP",
                "branding": "name",
                "logo_path": ""
            }
        }

        # Load or initialize manifest
        if os.path.exists(manifest_path):
            with open(manifest_path, 'r') as f:
                try:
                    config = json.load(f)
                    # Merge missing keys with defaults
                    config = {**default_config, **config}
                except json.JSONDecodeError:
                    config = default_config  # Handle invalid JSON
        else:
            config = default_config

        # Handle form submission
        if request.method == 'POST':
            # Update company name and branding
            config['site_settings']['company_name'] = request.form.get('company_name')
            config['site_settings']['branding'] = request.form.get('branding')
            config['theme_settings']['theme'] = request.form.get('theme')

            # Handle logo upload
            logo_file = request.files.get('logo')
            if logo_file and logo_file.filename:
                if allowed_file(logo_file.filename, ALLOWED_LOGO_EXTENSIONS):
                    logo_filename = secure_filename(logo_file.filename)
                    logo_path = os.path.join(STATIC_UPLOAD_FOLDER, logo_filename)
                    logo_file.save(logo_path)
                    config['site_settings']['logo_path'] = f"uploads/{logo_filename}"
                else:
                    flash("Invalid file type for logo. Allowed: png, jpg, jpeg, svg", 'danger')

            # Handle custom CSS upload
            css_file = request.files.get('custom_css')
            if css_file and css_file.filename:
                if allowed_file(css_file.filename, ALLOWED_CSS_EXTENSIONS):
                    css_filename = secure_filename(css_file.filename)
                    css_path = os.path.join(STATIC_UPLOAD_FOLDER, css_filename)
                    css_file.save(css_path)
                    config['theme_settings']['custom_css_path'] = f"uploads/{css_filename}"
                else:
                    flash("Invalid file type for custom CSS. Allowed: css", 'danger')

            # Save updated config
            with open(manifest_path, 'w') as f:
                json.dump(config, f, indent=4)

            core_manifest = plugin_manager.get_core_manifest()
    
            site_settings = core_manifest.get('site_settings', {
                'company_name': 'Sparrow ERP',
                'branding': 'name',
                'logo_path': ''
            })
            session['site_settings'] = site_settings

            flash("Core module settings updated successfully!", 'success')

        return render_template('core_module_settings.html', config=plugin_manager.get_core_manifest())
    else:
        flash("You need to log in first!", "warning")
        return redirect(url_for('routes.login'))


# Plugin settings route
@routes.route('/plugin/<plugin_system_name>/settings', methods=['GET', 'POST'])
def plugin_settings(plugin_system_name):
    if 'logged_in' in session and session['logged_in']:
        plugin_manager = PluginManager(PLUGINS_FOLDER)
        manifest = plugin_manager.get_plugin(plugin_system_name)
        if not manifest:
            print(f'Plugin manifest for {plugin_system_name} not found.', 'error')
            return redirect(url_for('routes.plugins'))

        # Handle form submission to update settings
        if request.method == 'POST':
            # Update the settings from the form data
            plugin_manager.update_plugin_settings(plugin_system_name, request.form)

            flash(f'{plugin_system_name} settings updated successfully!', 'success')

        return render_template('plugin_settings.html', plugin_name=plugin_system_name, settings=manifest, config=plugin_manager.get_core_manifest())
    else:
        flash('You need to log in first!', 'warning')
        return redirect(url_for('routes.login'))

# Enable plugin route
@routes.route('/plugin/<plugin_system_name>/enable', methods=['POST'])
def enable_plugin(plugin_system_name):
    if 'logged_in' in session and session['logged_in']:
        plugin_manager = PluginManager(PLUGINS_FOLDER)
        success = plugin_manager.enable_plugin(plugin_system_name)

        if success:
            flash(f'{plugin_system_name} has been enabled.', 'success')
        else:
            flash(f'{plugin_system_name} is not installed or manifest is missing.', 'error')

        return redirect(url_for('routes.plugins'))
    else:
        flash('You need to log in first!', 'warning')
        return redirect(url_for('routes.login'))

# Disable plugin route
@routes.route('/plugin/<plugin_system_name>/disable', methods=['POST'])
def disable_plugin(plugin_system_name):
    if 'logged_in' in session and session['logged_in']:
        plugin_manager = PluginManager(PLUGINS_FOLDER)
        success = plugin_manager.disable_plugin(plugin_system_name)

        if success:
            flash(f'{plugin_system_name} has been disabled.', 'success')
        else:
            flash(f'{plugin_system_name} is not installed or manifest is missing.', 'error')

        return redirect(url_for('routes.plugins'))
    else:
        flash('You need to log in first!', 'warning')
        return redirect(url_for('routes.login'))

# Install plugin route
@routes.route('/plugin/<plugin_system_name>/install', methods=['POST'])
def install_plugin(plugin_system_name):
    if 'logged_in' in session and session['logged_in']:
        plugin_manager = PluginManager(PLUGINS_FOLDER)
        success = plugin_manager.install_plugin(plugin_system_name)

        if success:
            flash(f'{plugin_system_name} has been installed successfully!', 'success')
        else:
            flash(f'Failed to install {plugin_system_name}. Please check the plugin files.', 'error')

        return redirect(url_for('routes.plugins'))
    else:
        flash('You need to log in first!', 'warning')
        return redirect(url_for('routes.login'))

# Uninstall plugin route
@routes.route('/plugin/<plugin_system_name>/uninstall', methods=['POST'])
def uninstall_plugin(plugin_system_name):
    if 'logged_in' in session and session['logged_in']:
        plugin_manager = PluginManager(PLUGINS_FOLDER)
        success = plugin_manager.uninstall_plugin(plugin_system_name)

        if success:
            flash(f'{plugin_system_name} has been uninstalled.', 'success')
        else:
            flash(f'{plugin_system_name} is not installed or manifest is missing.', 'error')

        return redirect(url_for('routes.plugins'))
    else:
        flash('You need to log in first!', 'warning')
        return redirect(url_for('routes.login'))

@routes.route('/plugins/<plugin_name>/<filename>')
def serve_plugin_icon(plugin_name, filename):
    plugin_folder = os.path.join(os.getcwd(), 'app', 'plugins', plugin_name)
    return send_from_directory(plugin_folder, filename)
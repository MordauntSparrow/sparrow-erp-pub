import os
import json
import subprocess
import sys
from flask import Flask

def restart_application():
    """Restart the application."""
    print("Restarting application to apply changes...")
    os.execv(sys.executable, [sys.executable] + sys.argv)

def create_app():
    """Create and configure the Flask app."""
    # Define paths
    CONFIG_FOLDER = os.path.join("app", "config")
    CORE_MANIFEST_PATH = os.path.join(CONFIG_FOLDER, "manifest.json")

    # Ensure config directory exists
    os.makedirs(CONFIG_FOLDER, exist_ok=True)

    # Check and create core manifest if not exists
    if not os.path.exists(CORE_MANIFEST_PATH):
        core_manifest = {
            "name": "Core Module",
            "system_name": "Sparrow_ERP_Core",
            "version": "1.0.0",
            "theme_settings": {
                "theme": "default",
                "custom_css_path": ""
            },
            "site_settings": {
                "company_name": "Sparrow ERP",
                "branding": "name",
                "logo_path": ""
            }
        }
        with open(CORE_MANIFEST_PATH, 'w') as f:
            json.dump(core_manifest, f, indent=4)
        print(f"Core manifest created at {CORE_MANIFEST_PATH}")

    # Path to dependency_handler.py
    dependency_handler_path = os.path.join("app", "dependency_handler.py")

    if not os.path.exists(dependency_handler_path):
        print(f"Error: Dependency handler not found at {dependency_handler_path}")
        sys.exit(1)

    # Run the dependency handler during startup
    try:
        print("Running dependency handler during application startup...")
        subprocess.check_call([sys.executable, dependency_handler_path])
    except subprocess.CalledProcessError as e:
        print(f"Dependency handler failed: {e}")
        sys.exit(1)

    # Attempt to import required modules
    try:
        from app.objects import PluginManager
        from app.plugins.website_module import WebsiteServer
    except ImportError as e:
        print(f"Error importing module: {e}. Attempting to install missing dependency...")
        missing_package = str(e).split("'")[1]  # Extract the missing package name
        subprocess.check_call([sys.executable, "-m", "pip", "install", missing_package])
        print(f"Installed missing dependency: {missing_package}. Restarting application...")
        restart_application()
    print("1")
    # Create the Flask admin app
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'mysecretkey'
    app.config['PUBLIC_SERVER_URL'] = 'http://localhost:80'
    print("2")
    # Register the admin routes
    from app.routes import routes
    app.register_blueprint(routes)
    print("3")
    # Initialize the plugin manager
    plugin_manager = PluginManager(plugins_dir='plugins')
    plugin_manager.register_admin_routes(app)
    print("4")
    # Check if the website module is enabled
    if plugin_manager.is_plugin_enabled('website_module'):
        # Start the website module using the WebsiteServer class
        website_server = WebsiteServer()
        website_server.start()
    print("5")
    return app
